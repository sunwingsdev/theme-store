const express = require("express");
const { ObjectId } = require("mongodb");

const usersApi = (usersCollection) => {
  const userRouter = express.Router();

  userRouter.post("/", async (req, res) => {
    const userInfo = req.body;
    userInfo.createdAt = new Date();
    userInfo.role = "user";
    const result = await usersCollection.insertOne(userInfo);
    res.send(result);
  });

  userRouter.get("/", async (req, res) => {
    const result = await usersCollection.find().toArray();
    res.send(result);
  });

  userRouter.get("/:uid", async (req, res) => {
    const { uid } = req.params;
    const query = { uid: uid };
    const result = await usersCollection.findOne(query);
    res.send(result);
  });

  userRouter.patch("/:id", async (req, res) => {
    const { id } = req.params;
    const query = { _id: new ObjectId(id) };
    const info = req.body;
    const updatedDoc = { $set: { role: info.role } };
    const result = await usersCollection.updateOne(query, updatedDoc);
    res.send(result);
  });

  return userRouter;
};

module.exports = usersApi;
